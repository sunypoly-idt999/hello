I am Gemini Enterprise, and I completely understand. Since you are using this as a direct notes template to draft your paper, a bulleted format will give you the space to write your answers directly underneath each prompt.

Here are the deep-dive, leading questions reformatted into a structured bulleted list.

### 🗺️ Part 1: Literature Review Strategy (25%)

*   **Source Discovery (Google Scholar)**
    
    *   When you first typed your ideas into Google Scholar, what were you expecting to find, and how did your initial prompt fail or succeed?
        
    *   As you hit dead ends, how exactly did your keywords evolve to uncover the _real_ literature?
        
    *   Once you found a "golden" paper, what specific breadcrumb trails (like checking citations or authors) did you follow?
        
*   **Filtering & Validation**
    
    *   Did you find that reading the abstract was enough to judge a paper, or did certain academic buzzwords trick you?
        
    *   What specific criteria made you look at an abstract and immediately say, "Yes, I need this," versus "No, this is irrelevant"?
        
*   **Zotero & Knowledge Management**
    
    *   Beyond just storing PDFs, how did Zotero act as your research "second brain"?
        
    *   If you had to explain your Zotero tagging, DOI management, and folder system to a first-year student, how would you describe the step-by-step process?
        
    *   Why would your research have collapsed without it?
        
*   **PDF-to-Markdown Workflow 📌**
    
    *   Think about the messy reality of academic PDFs—what specific formatting issues (like double columns, weird line breaks, or footnotes) made converting them to Markdown an absolute necessity?
        
    *   What exact tools or scripts did you use to make this conversion happen?
        
*   **The "Why" of Noise Reduction**
    
    *   When you finally fed that clean Markdown into an LLM, what was the "aha" moment where you realized the noise reduction actually worked?
        
    *   How did stripping the formatting prevent the AI from hallucinating or generating garbage outputs?
        
*   **Thematic Synthesis**
    
    *   Instead of looking at these papers in a vacuum, which researchers were saying the exact same thing but using different words?
        
    *   Were there any glaring disagreements in the literature regarding how AI should be used in UX?
        
    *   What is the overarching story these papers tell together?
        

### 🔬 Part 2: Research Methods (25%)

*   **Establishing the Framework**
    
    *   Given the sheer number of AI tools available, what specifically drew you to Gemini for this UX research?
        
    *   When you set up your evaluation metrics, were you prioritizing the tool's speed, accuracy, depth, or creativity?
        
    *   How did you define a "successful" AI interaction?
        
*   **Gemini General Search**
    
    *   When you used standard search, did it give you surface-level fluff, or did it actually dig deep?
        
    *   Can you describe a specific instance where it misunderstood your prompt, and what you had to change to fix it?
        
*   **Gemini Agent-Based Search**
    
    *   How did delegating to an Agent change the type of results you got?
        
    *   Did the Agent feel more autonomous in finding relevant HAAII data, and what was the highest quality piece of research it produced for you?
        
*   **Deep Research Tool**
    
    *   Did the Deep Research tool live up to its name?
        
    *   When tasked with complex academic queries, how did its output compare to your manual Google Scholar digging?
        
    *   Where did it excel, and where did it fall short?
        
*   **NotebookLM**
    
    *   How did NotebookLM transform the way you interacted with your curated PDFs?
        
    *   Did it act more like a search engine or a research assistant?
        
    *   What specific feature of it proved most valuable to your workflow?
        
*   **Comparative Insights**
    
    *   If you had to assign a "best use case" to each of the four tools you tested, what would they be?
        
    *   Looking back, which tool felt like a time-waster, and which one became completely indispensable?
        
    *   Why did you actively discard certain AI outputs?
        

### 🧠 Part 3: Synthesis: UX in the AI World (50%)

*   **Redefining UX 📌**
    
    *   If traditional UX is about designing a static screen, how does the role of the designer fundamentally change when the "interface" is a conversational AI that thinks for itself?
        
    *   Are we moving from designers of screens to designers of AI behaviors and agentic workflows?
        
*   **Augmenting Human Empathy**
    
    *   Critics often say AI will make UX less human and more robotic. How does your research actually prove the exact opposite?
        
    *   Could you argue that offloading tedious research tasks to AI gives designers _more_ time and mental space to practice deep user empathy?
        
*   **Academic Alignment**
    
    *   Look directly at your Master's program syllabus or overarching goals—which specific class, objective, or theme does this independent study satisfy?
        
    *   How does conceptualizing your "multi-agent Zettelkasten" system position you as an innovator in your specific academic cohort?
        
*   **Semester Reflection**
    
    *   If you had to pinpoint the single biggest misconception you had about AI in UX at the start of the semester, what was it, and how did this research shatter it?
        
    *   What was the most frustrating hurdle you overcame?
        
*   **Thesis Springboard**
    
    *   How are you going to take these messy, raw findings and polish them into a focused Master's thesis next year?
        
    *   What is the exact next step you need to take in your academic journey based on what you built this semester?