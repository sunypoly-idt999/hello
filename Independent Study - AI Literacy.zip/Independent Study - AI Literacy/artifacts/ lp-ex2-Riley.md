I have analyzed your provided bibliography. Your current sources establish a strong foundation in **Human-Centered AI (HCAI)**, **human-in-the-loop (HITL) coordination**, and the philosophy of **LLMs as co-creators** rather than replacements in UX workflows.

To complement your research, I have curated additional foundational and applied academic papers. These resources focus heavily on the practical integration of AI into UX design workflows, navigating AI as a "design material," and established guidelines for human-AI co-creation.

### 📌 Recommended Action

You can copy the raw list of DOIs below and paste them into Zotero using the **"Add Item by Identifier" (magic wand icon)**. Zotero will automatically fetch the titles, abstracts, authors, and metadata for your repository.

### Supplementary DOIs

Here is the curated list of DOIs representing key research from venues like CHI and DIS that directly align with your thesis on augmenting UX practices:

text

Plain textANTLR4BashCC#CSSCoffeeScriptCMakeDartDjangoDockerEJSErlangGitGoGraphQLGroovyHTMLJavaJavaScriptJSONJSXKotlinLaTeXLessLuaMakefileMarkdownMATLABMarkupObjective-CPerlPHPPowerShell.propertiesProtocol BuffersPythonRRubySass (Sass)Sass (Scss)SchemeSQLShellSwiftSVGTSXTypeScriptWebAssemblyYAMLXML`   10.1145/3290605.3300233  10.1145/3411764.3445479  10.1145/3313831.3376358  10.1145/3491102.3517475  10.1145/3025453.3025739  10.1145/3313831.3376590  10.1145/3491102.3502030   `

**Context on these additions:**These DOIs pull in foundational papers regarding _Guidelines for Human-AI Interaction_ (Amershi et al.), _UX Design Practice for AI-Enabled Systems_ (Subramonyam et al.), and qualitative studies on how experienced enterprise designers currently negotiate AI in their toolkits. They provide the practical "workflow" grounding to match your theoretical HCAI sources.