Böckle, Martin, et al. “Design Thinking and AI: Facilitating HCAI Solutions.” Handbook of Human-Centered Artificial Intelligence, Springer, Singapore, 2026, pp. 635–95. link.springer.com, [https://doi.org/10.1007/978-981-95-3658-0\_73](https://www.google.com/url?q=https://doi.org/10.1007/978-981-95-3658-0_73).

Davis, Nicholas. “Interaction-Centered Intelligence: Toward an Interaction-Based Theory of Human-AI Co-Creation.” arXiv:2606.00807, arXiv, 11 June 2026. arXiv.org, [https://doi.org/10.48550/arXiv.2606.00807](https://www.google.com/url?q=https://doi.org/10.48550/arXiv.2606.00807).

Drzyzga, Gilbert, and Monique Janneck. “User-Centered Design for Artificial Intelligence: A Toolkit for Evaluation, Refinement, and Implementation.” Artificial Intelligence in HCI, edited by Helmut Degen and Stavroula Ntoa, Springer Nature Switzerland, 2026, pp. 275–99. Springer Link, [https://doi.org/10.1007/978-3-032-30846-7\_17](https://www.google.com/url?q=https://doi.org/10.1007/978-3-032-30846-7_17).

Karthik, Harini, and Akshay Kore. “Designing Human-Centered AI Experiences.” Handbook of Human-Centered Artificial Intelligence, Springer, Singapore, 2026, pp. 769–831. link.springer.com, [https://doi.org/10.1007/978-981-95-3658-0\_33](https://www.google.com/url?q=https://doi.org/10.1007/978-981-95-3658-0_33).

L, Amudavalli. “Human–AI Interaction and Interpretability in User Interfaces.” International Journal of Artificial Intelligence & Digital Transformation, vol. 9, no. 1, Jan. 2026, pp. 13–21. worldcometresearchgroup.com, [https://worldcometresearchgroup.com/index.php/ijaidt/article/view/67](https://www.google.com/url?q=https://worldcometresearchgroup.com/index.php/ijaidt/article/view/67).

Lu, Yuwen, et al. “AI Assistance for UX: A Literature Review Through Human-Centered AI.” arXiv:2402.06089, arXiv, 13 Feb. 2024. arXiv.org, [https://doi.org/10.48550/arXiv.2402.06089](https://www.google.com/url?q=https://doi.org/10.48550/arXiv.2402.06089).

Mendo, João Rodrigo Afonso, et al. “Personalizing User Interfaces with Generative Artificial Intelligence: A Systematic Literature Review.” SSRN Scholarly Paper no. 6504480, Social Science Research Network, 1 Apr. 2026. papers.ssrn.com, [https://doi.org/10.2139/ssrn.6504480](https://www.google.com/url?q=https://doi.org/10.2139/ssrn.6504480).

Pierce, James, et al. “Human-AI Coordination Zones: A Framework for Designing Human-in-the-Loop Experiences with Agentic AI.” arXiv:2606.09848, arXiv, 1 May 2026. arXiv.org, [https://doi.org/10.48550/arXiv.2606.09848](https://www.google.com/url?q=https://doi.org/10.48550/arXiv.2606.09848).

Pypenko, I. S. “Human and Artificial Intelligence Interaction.” International Journal of Science Annals, vol. 6, no. 2, Dec. 2023, pp. 54–56. DOI.org (Crossref), [https://doi.org/10.26697/ijsa.2023.2.7](https://www.google.com/url?q=https://doi.org/10.26697/ijsa.2023.2.7).

Troussas, Christos, et al. “The Agency-First Framework: Operationalizing Human-Centric Interaction and Evaluation Heuristics for Generative AI.” Electronics, vol. 15, no. 4, Jan. 2026, p. 877. [www.mdpi.com](https://www.google.com/url?q=http://www.mdpi.com), [https://doi.org/10.3390/electronics15040877](https://www.google.com/url?q=https://doi.org/10.3390/electronics15040877).

Vishwarupe, Varad, et al. “‘To LLM, or Not to LLM?’: How Designers and Developers Navigate LLMs as Tools or Teammates.” Proceedings of the Extended Abstracts of the 2026 CHI Conference on Human Factors in Computing Systems \[New York, NY, USA\], CHI EA ’26, 2026, pp. 1–6. ACM Digital Library, [https://doi.org/10.1145/3772363.3798953](https://www.google.com/url?q=https://doi.org/10.1145/3772363.3798953).

Weisz, Justin D., et al. “Human-Centered AI Design Principles for Generative AI.” Handbook of Human-Centered Artificial Intelligence, Springer, Singapore, 2026, pp. 697–768. link.springer.com, [https://doi.org/10.1007/978-981-95-3658-0\_74](https://www.google.com/url?q=https://doi.org/10.1007/978-981-95-3658-0_74).

Xu, Wei, et al. “An HCAI Methodological Framework: Putting It Into Action to Enable Human-Centered AI.” IEEE Transactions on Human-Machine Systems, vol. 56, no. 1, Feb. 2026, pp. 78–94. IEEE Xplore, [https://doi.org/10.1109/THMS.2025.3631590](https://www.google.com/url?q=https://doi.org/10.1109/THMS.2025.3631590).

———. “Human-Centered AI (HCAI): Foundations and Approaches.” Handbook of Human-Centered Artificial Intelligence, Springer, Singapore, 2026, pp. 3–83. link.springer.com, [https://doi.org/10.1007/978-981-95-3658-0\_1](https://www.google.com/url?q=https://doi.org/10.1007/978-981-95-3658-0_1).

———. “Human-Centered Human-AI Interaction (HC-HAII): A Human-Centered AI Perspective.” Human-Centered AI: Advancing Research and Applications in  Human-AI Interaction, edited by Wei Xu, Springer Nature, 2026, pp. 3–55. Springer Link, [https://doi.org/10.1007/978-981-95-5585-7\_1](https://www.google.com/url?q=https://doi.org/10.1007/978-981-95-5585-7_1).

Zargham, Nima, et al. “Proactive Systems in HCI and AI: Concepts, Challenges, and Opportunities.” arXiv:2606.25149, arXiv, 23 June 2026. arXiv.org, [https://doi.org/10.48550/arXiv.2606.25149](https://www.google.com/url?q=https://doi.org/10.48550/arXiv.2606.25149).

Zhao, Chaoyi, and Wei Xu. “Human-AI Interaction Design Standards.” Human-Centered AI: Advancing Research and Applications in  Human-AI Interaction, edited by Wei Xu, Springer Nature, 2026, pp. 557–611. Springer Link, [https://doi.org/10.1007/978-981-95-5585-7\_16](https://www.google.com/url?q=https://doi.org/10.1007/978-981-95-5585-7_16).

Gemini replied

I have analyzed your provided bibliography. Your current sources establish a strong foundation in **Human-Centered AI (HCAI)**, **human-in-the-loop (HITL) coordination**, and the philosophy of **LLMs as co-creators** rather than replacements in UX workflows.

To complement your research, I have curated additional foundational and applied academic papers. These resources focus heavily on the practical integration of AI into UX design workflows, navigating AI as a "design material," and established guidelines for human-AI co-creation.

### 📌 Recommended Action

You can copy the raw list of DOIs below and paste them into Zotero using the **"Add Item by Identifier" (magic wand icon)**. Zotero will automatically fetch the titles, abstracts, authors, and metadata for your repository.

### Supplementary DOIs

Here is the curated list of DOIs representing key research from venues like CHI and DIS that directly align with your thesis on augmenting UX practices:

text

Plain textANTLR4BashCC#CSSCoffeeScriptCMakeDartDjangoDockerEJSErlangGitGoGraphQLGroovyHTMLJavaJavaScriptJSONJSXKotlinLaTeXLessLuaMakefileMarkdownMATLABMarkupObjective-CPerlPHPPowerShell.propertiesProtocol BuffersPythonRRubySass (Sass)Sass (Scss)SchemeSQLShellSwiftSVGTSXTypeScriptWebAssemblyYAMLXML`   10.1145/3290605.3300233  10.1145/3411764.3445479  10.1145/3313831.3376358  10.1145/3491102.3517475  10.1145/3025453.3025739  10.1145/3313831.3376590  10.1145/3491102.3502030   `

**Context on these additions:**These DOIs pull in foundational papers regarding _Guidelines for Human-AI Interaction_ (Amershi et al.), _UX Design Practice for AI-Enabled Systems_ (Subramonyam et al.), and qualitative studies on how experienced enterprise designers currently negotiate AI in their toolkits. They provide the practical "workflow" grounding to match your theoretical HCAI sources.